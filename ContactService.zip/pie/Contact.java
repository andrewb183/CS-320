package pie;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Contact {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
