package pie;


public class task {

   private String ID;
   private String name;
   private String desc;
  
   public task(String id, String name, String desc) {
       if (id.length() > 10 || id == null) {
           throw new IllegalArgumentException("Invalid Id");
       }
       if (name.length() > 20 || name == null) {
           throw new IllegalArgumentException("Invalid name");
       }
       if (desc.length() > 50 || desc == null) {
           throw new IllegalArgumentException("Invalid description");
       }
      
       this.ID = id;
       this.name = name;
       this.desc = desc;
   }

   public String getID() {
       return ID;
   }

   public String getName() {
       return name;
   }

   public String getDesc() {
       return desc;
   }

   public void updateName(String name) {
       this.name = name;
   }

   public void updateDesc(String desc) {
       this.desc = desc;
   }


}
      

